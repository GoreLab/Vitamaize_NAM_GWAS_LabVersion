sTASSEL.jar is a custom jar that has the following modficiations to StepwiseAdditiveModelFitterPlugin. New parameters are as follows:
" -sites : a comma separated list of site names (no spaces allowed, quotes are not necessary)"
 -fit : if true the model will attempt to fit additional sites after adding the initial sites list
 -rescanAlpha : defaults to 0.01 now but can be reset if desired
