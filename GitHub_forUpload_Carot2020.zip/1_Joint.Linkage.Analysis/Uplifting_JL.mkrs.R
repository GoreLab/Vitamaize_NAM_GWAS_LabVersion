setwd("C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/")
mkr.names.chr.pos = read.table("Master_Files_forJL/0.1_cM_Markers_for_TASSEL_with_Names_Sformat_names.only_forR.hmp.txt",sep='\t',head=T)
dim(mkr.names.chr.pos)

uplifted.mkrs.chr.pos = read.table("Summary_Tables.Figures/Uplifting/maize_0.1_cM_genetic_map.v2_v4.sort_forR.txt",sep = '\t',head=T)

mkr_nearest.mkr_nearest.outermkr = matrix(NA,nrow=nrow(mkr.names.chr.pos),ncol=10)
for(mkr.index in 1:nrow(mkr.names.chr.pos)){
  this.v2.mkr = as.data.frame(mkr.names.chr.pos[mkr.index,])
  this.v2.mkr.name = as.character(this.v2.mkr[,1])
  this.v2.mkr.chr = as.numeric(this.v2.mkr[,2])
  this.v2.mkr.pos = as.numeric(this.v2.mkr[,3])
  
  row.to.add = c(this.v2.mkr.name,this.v2.mkr.chr,this.v2.mkr.pos,NA,NA,NA,NA,NA,NA,NA)
  numb.to.subtract = 1
  numb.to.add = 1
  this.left.mkr.v4 = NULL
  this.right.mkr.v4 = NULL
  
  if(as.character(this.v2.mkr.name) %in% uplifted.mkrs.chr.pos[,1]){
    this.v4.mkr = uplifted.mkrs.chr.pos[which(uplifted.mkrs.chr.pos[,1] == this.v2.mkr.name),]
    this.v4.mkr.chr = as.character(this.v4.mkr[,4])
    this.v4.mkr.pos = as.character(this.v4.mkr[,5])
    row.to.add[c(4:10)] = c(this.v2.mkr.pos,this.v4.mkr.chr,this.v4.mkr.pos,this.v4.mkr.chr,this.v4.mkr.pos,this.v4.mkr.chr,this.v4.mkr.pos)
  }else{
    while(nrow(this.left.mkr.v4) == 0 || is.null(this.left.mkr.v4)){
    next.left = as.data.frame(mkr.names.chr.pos[mkr.index-numb.to.subtract,])
    this.left.mkr.v4 = as.data.frame(uplifted.mkrs.chr.pos[which(uplifted.mkrs.chr.pos[,1] == as.character(next.left[,1])),])
    numb.to.subtract = numb.to.subtract + 1
    }
    while(nrow(this.right.mkr.v4) == 0 || is.null(this.right.mkr.v4)){
    next.right = as.data.frame(mkr.names.chr.pos[mkr.index+numb.to.add,])
    this.right.mkr.v4 = as.data.frame(uplifted.mkrs.chr.pos[which(uplifted.mkrs.chr.pos[,1] == as.character(next.right[,1])),])
    numb.to.add = numb.to.add + 1
    }
    
    dist.to.left = next.left[,3] - this.v2.mkr.pos
    next.left.v4.chr = as.character(this.left.mkr.v4[,4])
    next.left.v4.pos = as.character(this.left.mkr.v4[,5])
    dist.to.right = next.right[,3] - this.v2.mkr.pos
    next.right.v4.chr = as.character(this.right.mkr.v4[,4])
    next.right.v4.pos = as.character(this.right.mkr.v4[,5])
    
    if(dist.to.left < dist.to.right){
      row.to.add[4:10] = c(as.character(next.left[,1]),next.left.v4.chr,next.left.v4.pos,next.left.v4.chr,next.left.v4.pos,next.right.v4.chr,next.right.v4.pos)
    }else if(dist.to.right < dist.to.left){
      row.to.add[c(4:10)] = c(as.character(next.right[,1]),next.right.v4.chr,next.right.v4.pos,next.left.v4.chr,next.left.v4.pos,next.right.v4.chr,next.right.v4.pos)
    }else if(dist.to.right == dist.to.left){
      print("Distances to the two nearest markers are equal")
    }
  }
  
  mkr_nearest.mkr_nearest.outermkr[mkr.index,] = row.to.add
}

colnames(mkr_nearest.mkr_nearest.outermkr) = c('id','v2_chr','v2_pos','v2_pos_nearest','v4_chr_nearest','v4_pos_nearest','v4_chr_nearest.left','v4_pos_nearest.left','v4_chr_nearest.right','v4_pos_nearest.right')
write.table(mkr_nearest.mkr_nearest.outermkr,"Summary_Tables.Figures/Uplifting/EachJLmkr_uplifted.to.nearest_nearest.outer.txt",sep='\t',quote=F,row.names=F)
