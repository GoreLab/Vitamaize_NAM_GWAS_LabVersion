#run this script on server using Rscript command, along with these parameters:
#############trait="[trait name]"
#############max_perm=[# of perms, default 1000]
#############n_chr_comp=[# of chromosomes for which all runs are complete,default 10]
#############input_dir="[input_dir]", default /share/maize_gwas/permutation_scripts-v3_1-20150402/analysis_output/
#############script_numb=ID for bash script run (this is how results are grouped);1 to 5
#Take the results and determine empirical null distributions for each of the chromosomes
#FYI, after talking with Alex we just chose the minimim to have ~0.01 cutoff, which turns out to be 2.7e-08
max_perm=1000
n_chr_comp=10
input_dir="/share/maize_gwas/permutation_scripts-v3_1-20150402/analysis_output/"

args = commandArgs(trailingOnly = TRUE)

for(i in 1:length(args)){
  arg_temp <- strsplit(args[i],'=')
  varKey = arg_temp[[1]][1]
  varVal = arg_temp[[1]][2]
  varEntry <- list(arg_temp[[1]][1],arg_temp[[1]][2])
  do.call("<-", varEntry)
}

print(trait)
n_chr_comp = as.integer(n_chr_comp)
print(n_chr_comp)
print(max_perm)

#path_for_inputs = paste(input_dir,"Complete_Results_BashPart",as.integer(script_numb),"/",trait,"_nulldist/", sep = '') #changed by CHD 4/16/2015--now inputting most of path as command-line param.
path_for_inputs = paste(input_dir,"Complete_Results_",trait,"/", sep = '') #CHD note 10/25/19: these are the latest results with CNVs removed (results with CNVs were moved to Complete_Results_Carot2019_withCNVs and new Complete_Results_[traitname] folders were re-created)
print(path_for_inputs)
setwd(path_for_inputs)
#path_for_outputs = dir.create("Summary") #ran this once on 4/21, don't need to run again
path_for_outputs=paste(path_for_inputs,"Summary",sep='')
setwd(path_for_outputs)

colClasses=c("integer","integer", "numeric","character",rep("numeric",4))
header=c("chr","pos","cM","allele","effect","fstat","pvalue","iteration")

#Load data
results=list()
for (chr in 1:n_chr_comp){
	#results[[chr]] = read.delim(file=paste("2b_chr",chr,"_model_results.txt", sep=""), colClasses=colClasses, header=F)  ##from JGW, CHD commented out 4/3/2015 and added line below
  results[[chr]] = read.delim(paste(path_for_inputs,trait,"_nulldist/",trait,"_model_chr",chr,"_",max_perm,"perm_results.txt", sep=""), colClasses=colClasses, header=F)
	names(results[[chr]])=header
}

#Compile
pvals=matrix(NA, nrow=NROW(results[[1]]), ncol=n_chr_comp)	#Matrix of p-values, one chromosome per column
colnames(pvals) = paste(rep("chr",n_chr_comp), 1:n_chr_comp, sep="")
for(j in 1:n_chr_comp){
  print(j)
  print(NROW(results[[j]]))
	rows=1:NROW(results[[j]])
	pvals[rows,j] = results[[j]]$pvalue
}

#Make histograms of results
log.pvals = -log10(pvals)
breaks=seq(from=0, to=max(log.pvals, na.rm=T)+1, by=0.5)
hists=list()
png("3_pval_histograms.png", width=300, height=300*n_chr_comp)
par(mfrow=c(n_chr_comp,1), cex=1.2)
for(k in 1:n_chr_comp){
	hists[[k]] = hist(log.pvals[,k], breaks=breaks, main=paste("Chromosome",k,"null dist"), xlab="-log10 pvalue", ylab="freq")
}
dev.off()

#Get quantiles
quants=matrix(NA, nrow=n_chr_comp+1, ncol=3)
colnames(quants)=c("0.1","0.05", "0.01") 
rownames(quants) = c(paste("chr", 1:n_chr_comp, sep=""), "mean")
for(m in 1:n_chr_comp){
	quants[m,] = quantile(pvals[,m],probs=c(0.1, 0.05, 0.01), na.rm=T)
}
quants[n_chr_comp+1,] = apply(X=quants[1:n_chr_comp,], MARGIN=2, FUN=mean)
write.table(x=quants, file="3_quantiles.txt", row.names=T, col.names=T, quote=F, sep="\t")

#Plot quantiles
log.quant = -log10(quants)
xvals=c(rep(1,n_chr_comp), rep(2,n_chr_comp), rep(3,n_chr_comp))
png("3_cutoffs.png", width=500, height=500)
par(cex=1.5)
plot(x=NA, y=NA, type="n", xlim=c(0.5,3.5), ylim=range(c(0,log.quant+1)), main="Empirical P-value cutoffs", xlab="Cutoff", ylab="-log10 pvalue", xaxt="n")
points(x=xvals, y=log.quant[1:n_chr_comp,], pch=1, cex=1.5)
points(x=1:3, y=log.quant[n_chr_comp+1,], pch=16, col="blue", cex=1.5)
axis(side=1, at=1:3, labels=colnames(quants))
dev.off()