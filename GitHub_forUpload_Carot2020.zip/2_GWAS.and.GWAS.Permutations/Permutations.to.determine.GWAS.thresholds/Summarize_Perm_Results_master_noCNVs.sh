#!/bin/bash
#
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="a_carotene"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="b_carotene"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="b_cryp"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="lutein"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="phytofluene"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="total_carot"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="zeaxanthin"
Rscript 3_AnalyzeNullDist_2019_noCNVs.r trait="zeino"
