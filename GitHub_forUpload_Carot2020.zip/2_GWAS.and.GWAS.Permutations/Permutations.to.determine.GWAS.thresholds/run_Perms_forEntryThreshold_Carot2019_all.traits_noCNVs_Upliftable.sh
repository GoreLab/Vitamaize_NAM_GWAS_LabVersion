#!/bin/bash
#
bash null_dist_noCNVs_Upliftable.sh -t a_carotene -r ../../data_input/Resid_from.R_a_carotene.SI.01.txt -i ../../data_input/ -o ../analysis_output/Complete_Results_a_carotene/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t b_carotene -r ../../data_input/Resid_from.R_b_carotene.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_b_carotene/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t b_cryp -r ../../data_input/Resid_from.R_b_cryp.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_b_cryp/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t lutein -r ../../data_input/Resid_from.R_lutein.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_lutein/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t phytofluene -r ../../data_input/Resid_from.R_phytofluene.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_phytofluene/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t total_carot -r ../../data_input/Resid_from.R_total_carot.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_total_carot/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t zeaxanthin -r ../../data_input/Resid_from.R_zeaxanthin.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_zeaxanthin/ -s 1 -c 10 -V -k
sleep 2m

bash null_dist_noCNVs_Upliftable.sh -t zeino -r ../../data_input/Resid_from.R_zeino.SI.01.txt  -i ../../data_input/ -o ../analysis_output/Complete_Results_zeino/ -s 1 -c 10 -V -k
sleep 2m
