Base code for GWAS and permutations to determine GWAS thresholds is otherwise the same as was posted on GitHub for Diepenbrock et al. 2017.
