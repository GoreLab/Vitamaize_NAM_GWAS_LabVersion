rm(list = ls())

##########################################################################
###Required files:
### (1) Tabular summary file with overlapping support intervals generated in script 3a
### (2) candidate gene list (see sample)
### (3) GWAS Results Summaries generated from script 2a, "Complete Results..." file

#File 3: Read in the file that shows HapMap (input data set for GWAS) SNP positions in v2 and corresponding positions in v4
#Verify that all SNPs from file 2 are present in file 3 (e.g. by SNP ID)
#Using v4 position for upliftable/uplifted GWAS SNPs, see which SNPs are in a v4 common support interval; keep a list of the v2 chr and v2 positions of those SNPs, will be the inputs to an adapted script 4a.

#Set the working directory
setwd("C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/")
GWAS.results.path = "C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/Master_Files_forGWAS/GWAS_Results_fromCBSU_CNVs.Removed_Actually.Upliftable/Summaries_by_Trait/" #CHD added 'Actually.' 2/26/2020
tabSummary.path = "C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/Summary_Tables.Figures/"

#Read in the appropriate filespast
#File 1: Read in the uplifted JL support interval coordinates (in v4)
cSIs.v4 = read.table(paste(tabSummary.path,"Uplifting/cSIs.in.v4.coords.txt",sep=''),sep='\t',head=T,stringsAsFactors=F)

#File 2: Obtain the GWAS results with RMIP>5
GWAS.results <- read.table(paste(GWAS.results.path,"Complete_Results_allTraits_RMIPgt4.txt", sep = ""),head = TRUE)
chr.of.GWAS.SNPs.to.extract <- NULL
pos.of.GWAS.SNPs.to.extract <- NULL

for(chr.counter in 1:10){
  GWAS.results.this.chr = GWAS.results[which(GWAS.results[,2] == chr.counter),]
  GWAS.SNPs.v2.to.v4 <- read.table(paste(tabSummary.path,"Uplifting/gwas_snps_full_set_v2_v4/gwas_snps_full_set.v2_v4.",chr.counter,".txt",sep=''),sep='\t',head=T,stringsAsFactors = F)
  
  for(i in 1:nrow(GWAS.results.this.chr)){
    GWAS.hit.v2.chr = as.numeric(GWAS.results.this.chr[i,2])
    GWAS.hit.v2.pos = as.numeric(GWAS.results.this.chr[i,3])
    GWAS.hit.v4.chr.w.prefix = GWAS.SNPs.v2.to.v4[which(GWAS.SNPs.v2.to.v4[,2] ==  GWAS.hit.v2.pos),3]
    GWAS.hit.v4.chr = as.numeric(substr(GWAS.hit.v4.chr.w.prefix,start=4,stop=5))
    GWAS.hit.v4.pos = GWAS.SNPs.v2.to.v4[which(GWAS.SNPs.v2.to.v4[,2] ==  GWAS.hit.v2.pos),4]
    
    #Obtain chromosome, start and stop support interval positions, from the "tabular summary"
    for(j in 1:nrow(cSIs.v4)){
      chr <- as.numeric(cSIs.v4[j, 2])
      QTL.start.bp <- as.numeric(cSIs.v4[j, 3])
      QTL.stop.bp <- as.numeric(cSIs.v4[j, 4])
      
      #If there are no SNPs within the JL support interval, STOP the script. Print out a message saying that JL and GWAS results do not overlap.
      if(GWAS.hit.v4.chr == chr & GWAS.hit.v4.pos > QTL.start.bp & GWAS.hit.v4.pos < QTL.stop.bp){
        chr.of.GWAS.SNPs.to.extract = c(chr.of.GWAS.SNPs.to.extract,GWAS.hit.v2.chr)
        pos.of.GWAS.SNPs.to.extract = c(pos.of.GWAS.SNPs.to.extract,GWAS.hit.v2.pos)
      }
    }
  }
}

output = cbind(chr.of.GWAS.SNPs.to.extract,pos.of.GWAS.SNPs.to.extract)
#Output the GWAS SNPs
write.table(output, paste(tabSummary.path,"chr.pos.of.GWAS.SNPs.to.extract.txt",sep=''),sep='\t',quote=F,row.names=F)