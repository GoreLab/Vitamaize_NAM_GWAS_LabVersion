setwd("C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/")
home.dir <- getwd()
GWAS.results.dir = "C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/Master_Files_forGWAS/GWAS_Results_fromCBSU_CNVs.Removed_Actually.Upliftable/Summaries_by_Trait/" #CHD added 'Actually.' 2/26/2020
tabSummary.path = "C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/Summary_Tables.Figures/"

all.signif.RMIP.SNPs = read.table(paste(GWAS.results.dir,"Complete_Results_allTraits_RMIPgt4_v4.pos.appended.txt",sep=''),head=TRUE,stringsAsFactors=FALSE) #CHD removed _dT3.Removed 11/4/19
commonSI.summ = read.table(paste(tabSummary.path,"Tab_Sum_Final_carot_0904_with_Common_SI_Info_left_bound_all.coords.in.v4.txt", sep = ""), sep="\t",head = TRUE) #CHD added _all.coords.in.v4 suffix 3/22/2020

which.cSI.this.RMIP.vect = rep(NA,nrow(all.signif.RMIP.SNPs))
for(SNP in (1:nrow(all.signif.RMIP.SNPs))){
  this.row = all.signif.RMIP.SNPs[SNP,]
  chr.SNP = as.character(substr(this.row[4],4,5)) #CHD changed from 2 to 4 to use v4_chr
  trait.SNP = as.character(this.row[1])
  pos.SNP = as.numeric(this.row[5]) #CHD changed from 3 to 5 to use v4_pos
  
  RMIP.SNP.vect = c(trait.SNP,chr.SNP)
  #if chr,pos,trait of SNP matches that combo for any row in master.commonSI.summary 
  trait.chr.match = subset(commonSI.summ,commonSI.summ[,1] == trait.SNP & commonSI.summ[,2] == chr.SNP)
  print(nrow(trait.chr.match))
  if(nrow(trait.chr.match)==0){
    next
  } else {
  for (match.row in (1:nrow(trait.chr.match))){
    this.row.cSI = trait.chr.match[match.row,]
      indiv.trait.SI.left = as.numeric(this.row.cSI[4])
      indiv.trait.SI.right = as.numeric(this.row.cSI[5])
    if (pos.SNP >= indiv.trait.SI.left && pos.SNP <= indiv.trait.SI.right){
      which.cSI.this.RMIP.vect[SNP] = as.numeric(this.row.cSI[12])
      print(pos.SNP)
      print(this.row.cSI[12])
    }
  }
}
}

RMIP.annot.by.cSI = cbind(all.signif.RMIP.SNPs,which.cSI.this.RMIP.vect)
write.table(RMIP.annot.by.cSI,paste(GWAS.results.dir,"Complete_Results_allTraits_RMIPgt4_with_QTLnumber_based.on.v4.coords.txt",sep=''),sep='\t',row.names=FALSE,quote=FALSE)