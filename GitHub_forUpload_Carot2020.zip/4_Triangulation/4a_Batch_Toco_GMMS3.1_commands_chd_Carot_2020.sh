#!/bin/sh

perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 13872274 --stop 27339452 -o results_file_QTL1_chr_1_region_13872274-27339452.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 57947091 --stop 96601388 -o results_file_QTL2_chr_1_region_57947091-96601388.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 217267962 --stop 224159620 -o results_file_QTL3_chr_1_region_217267962-224159620.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 279920453 --stop 292219987 -o results_file_QTL4_chr_1_region_279920453-292219987.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 1549203 --stop 4190118 -o results_file_QTL5_chr_2_region_1549203-4190118.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 13801340 --stop 18075169 -o results_file_QTL6_chr_2_region_13801340-18075169.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 41114121 --stop 141009235 -o results_file_QTL7_chr_2_region_41114121-141009235.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 223622126 --stop 230971345 -o results_file_QTL8_chr_2_region_223622126-230971345.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 28717244 --stop 53145713 -o results_file_QTL9_chr_3_region_28717244-53145713.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 121506153 --stop 164787824 -o results_file_QTL10_chr_3_region_121506153-164787824.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 175436374 --stop 178076511 -o results_file_QTL11_chr_3_region_175436374-178076511.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 209492783 --stop 209589899 -o results_file_QTL12_chr_3_region_209492783-209589899.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 83463 --stop 2871074 -o results_file_QTL13_chr_4_region_83463-2871074.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 23800632 --stop 158099286 -o results_file_QTL14_chr_4_region_23800632-158099286.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 160070821 --stop 167097417 -o results_file_QTL15_chr_4_region_160070821-167097417.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 172210143 --stop 176418358 -o results_file_QTL16_chr_4_region_172210143-176418358.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 187831139 --stop 203120788 -o results_file_QTL17_chr_4_region_187831139-203120788.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 235053483 --stop 236578901 -o results_file_QTL18_chr_4_region_235053483-236578901.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 35901 --stop 4173469 -o results_file_QTL19_chr_5_region_35901-4173469.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 10663891 --stop 14459567 -o results_file_QTL20_chr_5_region_10663891-14459567.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 38484956 --stop 65275605 -o results_file_QTL21_chr_5_region_38484956-65275605.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 71846725 --stop 152919029 -o results_file_QTL22_chr_5_region_71846725-152919029.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 196414978 --stop 200613961 -o results_file_QTL23_chr_5_region_196414978-200613961.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 25367187 --stop 68756663 -o results_file_QTL24_chr_6_region_25367187-68756663.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 76101427 --stop 84787343 -o results_file_QTL25_chr_6_region_76101427-84787343.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 145288053 --stop 150676701 -o results_file_QTL26_chr_6_region_145288053-150676701.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 13608958 --stop 15564626 -o results_file_QTL27_chr_7_region_13608958-15564626.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 127965942 --stop 154125428 -o results_file_QTL28_chr_7_region_127965942-154125428.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 163983403 --stop 167612936 -o results_file_QTL29_chr_7_region_163983403-167612936.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 170366928 --stop 176576894 -o results_file_QTL30_chr_7_region_170366928-176576894.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 12203658 --stop 91993060 -o results_file_QTL31_chr_8_region_12203658-91993060.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 118035019 --stop 132879659 -o results_file_QTL32_chr_8_region_118035019-132879659.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 138052988 --stop 139355739 -o results_file_QTL33_chr_8_region_138052988-139355739.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 4677210 --stop 11461387 -o results_file_QTL34_chr_9_region_4677210-11461387.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 18413830 --stop 24235042 -o results_file_QTL35_chr_9_region_18413830-24235042.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 141700189 --stop 142813539 -o results_file_QTL36_chr_9_region_141700189-142813539.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 146587518 --stop 149075084 -o results_file_QTL37_chr_9_region_146587518-149075084.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 149252059 --stop 151653476 -o results_file_QTL38_chr_9_region_149252059-151653476.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 153670708 --stop 153710296 -o results_file_QTL39_chr_9_region_153670708-153710296.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 153848853 --stop 156582266 -o results_file_QTL40_chr_9_region_153848853-156582266.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 22230600 --stop 85493385 -o results_file_QTL41_chr_10_region_22230600-85493385.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 106953191 --stop 124526091 -o results_file_QTL42_chr_10_region_106953191-124526091.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 135178221 --stop 136941040 -o results_file_QTL43_chr_10_region_135178221-136941040.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 143372575 --stop 146353117 -o results_file_QTL44_chr_10_region_143372575-146353117.txt -i

#  4a_Shell_for_perl.sh
#  
#
#  Created by John Doe on 6/6/16.
#
