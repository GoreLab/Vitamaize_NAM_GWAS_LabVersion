#!/bin/sh

perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 14075733 --stop 27535773 -o results_file_QTL1_chr_1_region_14075733-27535773.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 58645857 --stop 98879340 -o results_file_QTL2_chr_1_region_58645857-98879340.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 220457238 --stop 227778682 -o results_file_QTL3_chr_1_region_220457238-227778682.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 1 --start 285031402 --stop 297741693 -o results_file_QTL4_chr_1_region_285031402-297741693.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 1544161 --stop 4153823 -o results_file_QTL5_chr_2_region_1544161-4153823.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 14104893 --stop 19284705 -o results_file_QTL6_chr_2_region_14104893-19284705.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 42880702 --stop 145810716 -o results_file_QTL7_chr_2_region_42880702-145810716.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 2 --start 230676014 --stop 237990567 -o results_file_QTL8_chr_2_region_230676014-237990567.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 28290482 --stop 53039147 -o results_file_QTL9_chr_3_region_28290482-53039147.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 121782685 --stop 167653005 -o results_file_QTL10_chr_3_region_121782685-167653005.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 177994095 --stop 180966010 -o results_file_QTL11_chr_3_region_177994095-180966010.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 3 --start 213111341 --stop 298605572 -o results_file_QTL12_chr_3_region_213111341-298605572.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 25297006 --stop 161717577 -o results_file_QTL14_chr_4_region_25297006-161717577.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 163091091 --stop 170143105 -o results_file_QTL15_chr_4_region_163091091-170143105.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 175171450 --stop 179466301 -o results_file_QTL16_chr_4_region_175171450-179466301.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 191325696 --stop 207980701 -o results_file_QTL17_chr_4_region_191325696-207980701.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 4 --start 240232930 --stop 241817629 -o results_file_QTL18_chr_4_region_240232930-241817629.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 48254 --stop 4281923 -o results_file_QTL19_chr_5_region_48254-4281923.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 10949875 --stop 15025074 -o results_file_QTL20_chr_5_region_10949875-15025074.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 39728254 --stop 67769768 -o results_file_QTL21_chr_5_region_39728254-67769768.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 73930004 --stop 156654624 -o results_file_QTL22_chr_5_region_73930004-156654624.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 5 --start 201597300 --stop 206273925 -o results_file_QTL23_chr_5_region_201597300-206273925.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 26744299 --stop 73741563 -o results_file_QTL24_chr_6_region_26744299-73741563.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 79036195 --stop 87899050 -o results_file_QTL25_chr_6_region_79036195-87899050.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 6 --start 149247267 --stop 154797753 -o results_file_QTL26_chr_6_region_149247267-154797753.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 14072218 --stop 16177375 -o results_file_QTL27_chr_7_region_14072218-16177375.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 131948119 --stop 159423951 -o results_file_QTL28_chr_7_region_131948119-159423951.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 169508348 --stop 173170766 -o results_file_QTL29_chr_7_region_169508348-173170766.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 7 --start 175932276 --stop 182182294 -o results_file_QTL30_chr_7_region_175932276-182182294.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 12587104 --stop 93781941 -o results_file_QTL31_chr_8_region_12587104-93781941.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 120968877 --stop 136860593 -o results_file_QTL32_chr_8_region_120968877-136860593.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 8 --start 142127698 --stop 143509272 -o results_file_QTL33_chr_8_region_142127698-143509272.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 4275510 --stop 10874067 -o results_file_QTL34_chr_9_region_4275510-10874067.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 18268286 --stop 24342405 -o results_file_QTL35_chr_9_region_18268286-24342405.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 144384907 --stop 145525282 -o results_file_QTL36_chr_9_region_144384907-145525282.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 149389042 --stop 152202194 -o results_file_QTL37_chr_9_region_149389042-152202194.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 152382205 --stop 154805019 -o results_file_QTL38_chr_9_region_152382205-154805019.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 156832436 --stop 156868154 -o results_file_QTL39_chr_9_region_156832436-156868154.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 9 --start 156996638 --stop 159677758 -o results_file_QTL40_chr_9_region_156996638-159677758.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 20852258 --stop 85471303 -o results_file_QTL41_chr_10_region_20852258-85471303.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 107650507 --stop 125573758 -o results_file_QTL42_chr_10_region_107650507-125573758.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 136412737 --stop 138139264 -o results_file_QTL43_chr_10_region_136412737-138139264.txt -i
perl get_me_my_SNPs_v3.1_Up.pl --chr 10 --start 144085674 --stop 147130804 -o results_file_QTL44_chr_10_region_144085674-147130804.txt -i

#  4a_Shell_for_perl.sh
#  
#
#  Created by John Doe on 6/6/16.
#
