rm(list = ls())
###############
#saved in CBK files as: pleiotropy_network_for_Alex_CBK_markup_individual_QTL_and_PVEs_corr_network.r



###Required files:
### (1) Merged tab summary and pleiotropy matrix file generated from script (7-2), containing common SI tracker column 
        #ADDITIONAL NOTES: You may want to add another candidate gene column to your file, and ensure that the same candidate gene is listed for all QTL in the same common SI - helps graph labels later
        #IMPORTANT CHECK: trait names in r script vectors must match up with trait names in file column or row headers, else matrices will not be defined

###Output generated:
### (1) Pleiotropy graphs for common.SI, here noted as individual QTL



#read in pleiotropy matrix
setwd("C:/Users/chdiep/Documents/Model_Fitting_2019_from.Server/")
home.dir = getwd()
trait.set = "carot"
data <- read.table(paste("Summary_Tables.Figures/Pleiotropy_14Fam/Matrix/Pleiotropic.Output.Matrix.for.",trait.set,".SI01.TAB.SUM.MERGE_with.dT3.redone_sign.corrected_withCommonSIfrom25.txt",sep =""), head = TRUE,stringsAsFactors=FALSE)

#select subset of columns including original trait[,1], common.SI.tracker[,10], and traits tested[,18:26]
#pleio.matrix <- cbind(data[,1], data[,8:10], data[,11:19])
pleio.matrix <- cbind(data[,1], data[,8:9],data[,20], data[,12:19])

#colnames(pleio.matrix) <- c("Original_Trait", "PVE", "Cand.gene.title", "Common.SI.tracker", "ACAR", "PHYF", "BCRY", "LUT", "ZEI", "TOTCAR", "BCAR", "ZEA", "THLYC")
colnames(pleio.matrix) <- c("Original_Trait", "PVE", "Cand.gene.title", "Common.SI.tracker", "a_carotene","b_carotene","b_cryp","lutein","phytofluene","zeaxanthin","zeino","total_carot")
######################################################################
#generate matrix of 1, 0 and -1 specifying if correlation is significant at a=0.01, r=0.495

#specify the order in which you would like the traits to show up in the network, note that the linear vector will be displayed clockwise                       
#desired.column.order <- c("Original_Trait", "PVE", "Cand.gene.title", "Common.SI.tracker", "ACAR", "ZEI", "LUT", "PHYF", "THLYC", "ZEA", "BCRY", "BCAR", "TOTCAR")  
desired.column.order <- c("Original_Trait","PVE", "Cand.gene.title", "Common.SI.tracker", "phytofluene","a_carotene","zeino","lutein","total_carot","b_carotene","b_cryp","zeaxanthin") 
#no.totcar.column.order <- c("Original_Trait", "PVE", "Cand.gene.title", "Common.SI.tracker", "ACAR", "ZEI", "LUT", "PHYF", "THLYC", "ZEA", "BCRY", "BCAR")
#no.sum.traits.column.order <- c("Original_Trait","PVE", "Cand.gene.title", "Common.SI.tracker","PC8","gT","aT","dT","dT3","aT3","gT3")

#Reorder the trait names in your data file according to desired.column.order
pleio.matrix <- pleio.matrix[,desired.column.order]    #traits put in desired order for network output, according to Dean

#removing the "total carotenoid" trait to make the colnames vector look like no.totcar.column.order in line 13
#pleio.matrix.only.traits <- pleio.matrix[,1:length(no.totcar.column.order)]

#you can use this conditional statement if you want to have flexibility to compare trait vector with and without total traits
#FYI: total traits are helpful to use in visual graphic for individual QTL, but usually impair meaning in the genomewide graphs
totals.included = TRUE #INPUT REQUIRED*****************
if (totals.included == TRUE) {pleio.matrix <- pleio.matrix
  }else{pleio.matrix <- pleio.matrix.only.traits}

traits <- colnames(pleio.matrix[5:ncol(pleio.matrix)])                #INPUT: columns containing traits
col.of.interest <- c(5:ncol(pleio.matrix))                            #INPUT: column numbers containing traits
common.si.tracker <- unique(pleio.matrix[,4])

 for (k in common.si.tracker){          #loop ends on line 138
  
  #subset data out by common SI
  subset.pleio.matrix <- pleio.matrix[which(pleio.matrix[,4] == k),] 
  if(nrow(subset.pleio.matrix) == 0){
    next
  }
  
  #generate new matrix to hold sig pos, sig neg, non sig correlations, and identities, insert number of traits to be analyzed
  new.pleio.matrix <- matrix(NA, length(traits), ncol(subset.pleio.matrix))                
  colnames(new.pleio.matrix) <- colnames(subset.pleio.matrix)
  rownames(new.pleio.matrix) <- traits
  
  
  #generate pos.matrix, containing all positive correlations
  sig.pos.matrix <- new.pleio.matrix
  pos.threshold <- 0 #typically 0.495, note that this could be superceded by using significance threshold in script (7-1) line 141
  for (i in 1:nrow(subset.pleio.matrix)){
    for (j in col.of.interest){
      if(is.na(subset.pleio.matrix[i,j])){subset.pleio.matrix[i,j] == 1
      }else if (subset.pleio.matrix[i,j] == 1) {sig.pos.matrix[which(rownames(sig.pos.matrix) == subset.pleio.matrix[i,1]),j] = NA   #used to equal 3
      }else if (subset.pleio.matrix[i,j] >= pos.threshold) {sig.pos.matrix[which(rownames(sig.pos.matrix) == subset.pleio.matrix[i,1]),j] = subset.pleio.matrix[i,j] 
      }else{sig.pos.matrix[which(rownames(sig.pos.matrix) == subset.pleio.matrix[i,1]),j] = 0} 
    } # end j columns 
  } #end i rows of pleio.matrix
                                                                 
 
  #condense pos.matrix
  #pleio.matrix <- as.data.frame(pleio.matrix)       
  subset.pleio.matrix <- as.data.frame(subset.pleio.matrix)
  sig.pos.matrix.rename <- sig.pos.matrix[,5:ncol(sig.pos.matrix)]  #condenses original trait identifiers to pos, neg, non-sig matrix
  colnames(sig.pos.matrix.rename) <- traits
  rownames(sig.pos.matrix.rename) <- traits
  
  #generate neg.matrix, containing all negative correlations
  sig.neg.matrix <- new.pleio.matrix
  neg.threshold <- 0 #typically -0.495, note that this could be superceded by using significance threshold in script (7-1) line 141
    for (i in 1:nrow(subset.pleio.matrix)){
      for (j in col.of.interest){
        if(is.na(subset.pleio.matrix[i,j])){sig.neg.matrix[which(rownames(sig.neg.matrix) == subset.pleio.matrix[i,1]),j] = 0
        }else if (subset.pleio.matrix[i,j] == 1) {sig.neg.matrix[which(rownames(sig.neg.matrix) == subset.pleio.matrix[i,1]),j] = NA   #used to equal 3
        }else if (subset.pleio.matrix[i,j] <= neg.threshold) {sig.neg.matrix[which(rownames(sig.neg.matrix) == subset.pleio.matrix[i,1]),j] = abs(subset.pleio.matrix[i,j]) 
        }else{sig.neg.matrix[which(rownames(sig.neg.matrix) == subset.pleio.matrix[i,1]),j] = 0} 
      } # end j columns 
    } #end i rows of pleio.matrix
                                                                   
  
  #condense neg.matrix 
  #pleio.matrix <- as.data.frame(pleio.matrix)       
  subset.pleio.matrix <- as.data.frame(subset.pleio.matrix)
  sig.neg.matrix.rename <- sig.neg.matrix[,5:ncol(sig.neg.matrix)]  #condenses original trait identifiers to pos, neg, non-sig matrix
  colnames(sig.neg.matrix.rename) <- traits
  rownames(sig.neg.matrix.rename) <- traits


################  REMOVED ORIGINAL CODE FROM THIS SECTION     #######################################


 #Translation to input for Pat code
 shared_inflo1 <- sig.pos.matrix.rename
 shared_inflo2 <- sig.neg.matrix.rename


###if fewer than 1% of comparisons show pleiotropy at p<.01, change to 0
###scale by % pleiotropic QTL
###add up sig_pos and sig_neg in both directions
###these 3 matrices are now symmetrical
sig_pos=matrix(NA,length(traits),length(traits))    #matrix of NA, row and column length sized to the total number of traits
sig_neg=matrix(NA,length(traits),length(traits))    #matrix of NA, row and column length sized to the total number of traits
#pleiotropy_matrix=matrix(NA,length(traits),length(traits))            #17 traits total?
cutoff <- 0
for (i in 1:length(traits)){
  for (j in 1:length(traits)){
    #pos=(shared_inflo1[i,j]+shared_inflo1[j,i])/(shared_inflo1[i,i]+shared_inflo1[j,j])           #shared_inflo1 file contains actual number of sig pos corr - name of pos corr matrix
    #neg=(shared_inflo2[i,j]+shared_inflo2[j,i])/(shared_inflo1[i,i]+shared_inflo1[j,j])           #shared_inflo2 file contains actual number of sig neg corr - name of neg corr matrix
    pos=(shared_inflo1[i,j]+shared_inflo1[j,i])/(2)           #shared_inflo1 file contains actual number of sig pos corr - name of pos corr matrix
    neg=(shared_inflo2[i,j]+shared_inflo2[j,i])/(2)           #shared_inflo2 file contains actual number of sig neg corr - name of neg corr matrix
    sig_pos[i,j]=ifelse((pos+neg)>cutoff,pos,0)     #if sum of pos and neg ratios > cutoff (presumably 0.1), then keep pos corr value, otherwise store 0
    sig_neg[i,j]=ifelse((pos+neg)>cutoff,neg,0)     #if sum of pos and neg ratios > cutoff (presumably 0.1), then keep neg corr value, otherwise store 0
    #pleiotropy_matrix[i,j]=sig_pos[i,j]+sig_neg[i,j]   #in pleio matrix cell, store addition of positive and negative ratios
  }}

###color matrix: col=2 if only positive pleiotropy; col=3 if only negative pleiotropy;
###col=0 if no pleiotropy; col=5 if both positive and negative
#col_matrix=matrix(NA,length(traits),length(traits))
#for (i in 1:length(traits)){
#  for (j in 1:length(traits)){		
#    col_matrix[i,j]=ifelse(sig_pos[i,j]>0&sig_neg[i,j]==0,3,ifelse(sig_pos[i,j]==0&sig_neg[i,j]>0,2,ifelse(sig_pos[i,j]==0&sig_neg[i,j]==0,0,6)))
  #}}

col_matrix.pos=matrix(NA,length(traits),length(traits))
for (i in 1:length(traits)){
  for (j in 1:length(traits)){		
    #col_matrix[i,j]=ifelse(sig_pos[i,j]>0&sig_neg[i,j]==0,3,ifelse(sig_pos[i,j]==0&sig_neg[i,j]>0,2,ifelse(sig_pos[i,j]==0&sig_neg[i,j]==0,0,6)))
    col_matrix.pos[i,j]=ifelse(sig_pos[i,j]>0,'purple',0) #CHD changed 3 to purple
  }}

#negative network only
col_matrix.neg=matrix(NA,length(traits),length(traits))
for (i in 1:length(traits)){
  for (j in 1:length(traits)){		
    #col_matrix[i,j]=ifelse(sig_pos[i,j]>0&sig_neg[i,j]==0,3,ifelse(sig_pos[i,j]==0&sig_neg[i,j]>0,2,ifelse(sig_pos[i,j]==0&sig_neg[i,j]==0,0,6)))
    col_matrix.neg[i,j]=ifelse(sig_neg[i,j]>0,'orange',0)
  }}




#organizing names
#specify gene.candidate (id in column 3)
 gene.name <- subset.pleio.matrix[1,3]

#specify range of PVE  (range in column 2)
 upper.range <- substr(max(subset.pleio.matrix[,2]),1,5)
 lower.range <- substr(min(subset.pleio.matrix[,2]),1,5)




   ###################################### NOTE: network graph using line widths based on sig_pos, sig_neg or pleiotropy_matrix matrices are individually generated   #####################
###lty matrix: give dotted line to weaker pleiotropy
#lty_matrix=apply(pleiotropy_matrix,c(1,2),function(x){ifelse(x>0.25,"solid",ifelse(x<0.1&x>0,"dotted",ifelse(x==0,"blank","dashed")))})
library(network)
inflo_network=as.network.matrix(sig_pos)
png(paste(home.dir,"/Summary_Tables.Figures/Pleiotropy_14Fam/Graphs/byQTL/QTL-",k,".PVE-",lower.range,"-",upper.range,".POScorr.png",sep=""),height=8,width=8,units="in",res=300)
par(mar=c(0,0,0,0),oma=c(0,0,0,0))
#plot.network(inflo_network,label=traits,mode="circle",edge.lwd=pleiotropy_matrix*15,usearrows=F,label.cex=1.7,boxed.labels=F,edge.col=col_matrix,vertex.col=colors,vertex.cex=1.7,vertex.sides=30)
plot.network(inflo_network,label=traits,mode="circle",edge.lwd=sig_pos*25,usearrows=F,label.cex=1.2,boxed.labels=F,edge.col=col_matrix.pos,vertex.cex=1.2,vertex.sides=50,vertex.col='gray')

dev.off()

###lty matrix: give dotted line to weaker pleiotropy
#lty_matrix=apply(pleiotropy_matrix,c(1,2),function(x){ifelse(x>0.25,"solid",ifelse(x<0.1&x>0,"dotted",ifelse(x==0,"blank","dashed")))})
library(network)
inflo_network=as.network.matrix(sig_neg)
png(paste(home.dir,"/Summary_Tables.Figures/Pleiotropy_14Fam/Graphs/byQTL/QTL-",k,".PVE-",lower.range,"-",upper.range,".NEGcorr.png",sep=""),height=8,width=8,units="in",res=300)
par(mar=c(0,0,0,0),oma=c(0,0,0,0))
#plot.network(inflo_network,label=traits,mode="circle",edge.lwd=pleiotropy_matrix*15,usearrows=F,label.cex=1.7,boxed.labels=F,edge.col=col_matrix,vertex.col=colors,vertex.cex=1.7,vertex.sides=30)
plot.network(inflo_network,label=traits,mode="circle",edge.lwd=sig_neg*25,usearrows=F,label.cex=1.2,boxed.labels=F,edge.col=col_matrix.neg,vertex.cex=1.2,vertex.sides=50,vertex.col='gray')

dev.off()


                                                                                                              
 } #end k loop for common.si.tracker
